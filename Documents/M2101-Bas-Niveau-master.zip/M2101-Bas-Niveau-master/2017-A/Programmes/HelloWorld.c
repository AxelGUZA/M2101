#include <stdio.h>

int main(void) {
	char message[] = "Bonjour Limoges !\n";
	for (int i = 0; i < 10; i++)
		printf("%s\n", message);
	return 0;
}

// © Thomas Hugel 2017.
// License: Creative Commons BY-NC-SA 4.0.
