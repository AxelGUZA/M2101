Copyright Thomas Hugel 2018.

This work is licensed under the Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International License.

In any reuse of this work, please include a link to: http://thomas-hugel.gitlab.io/

To view a copy of this license, visit http://creativecommons.org/licenses/by-nc-sa/4.0/ or send a letter to Creative Commons, PO Box 1866, Mountain View, CA 94042, USA.
